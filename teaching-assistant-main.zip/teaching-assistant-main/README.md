step 1 : install all dependencies
step 2 : In teriminal npm run dev
step 3 : execution
